## ------------------------------------------------------------------------
data(bmov, package = "BristolVis")
head(bmov)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  require(ggplot2)
#  require(plotly)
#  (G = ggplot(bmov, aes(Length, Rating)) + geom_point())

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  summary(bmov$Year)
#  bmov$cat_timing = cut(bmov$Year, breaks = c(1930, 1990, 2000, 2005))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = ggplot(bmov, aes(Length, Rating, color = cat_timing)) + geom_point())

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = G + scale_color_manual(values = c("blue", "yellow", "red")))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  Fig_scatter = ggplotly(G)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  htmlwidgets::saveWidget(Fig_scatter, "Fig_scatter.html")

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  G = ggplot(bmov[bmov$Year>=1980,], aes(Year)) + geom_histogram()

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  G = G + geom_histogram(bins = 25)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  Fig_hist = ggplotly(G)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  htmlwidgets::saveWidget(Fig_hist, "Fig_hist.html")

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  G = ggplot(bmov, aes(x=cat_timing, y =Rating)) + geom_boxplot(aes(group = cat_timing))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  Fig_box = ggplotly(G)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  htmlwidgets::saveWidget(Fig_box, "Fig_box.html")

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  data(iris)
#  head(iris)
#  require(ggcorrplot)
#  data_cont = iris[,1:4]
#  Corr = cor(data_cont)
#  corr.p = cor_pmat(data_cont)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = ggcorrplot(Corr, method = "circle"))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = ggcorrplot(Corr, hc.order = TRUE, type = "lower"))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = ggcorrplot(Corr, hc.order = TRUE, type = "lower", p.mat = corr.p, sig.level = 0.01))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G = ggcorrplot(Corr, hc.order = TRUE, type = "lower", p.mat = corr.p, sig.level = 0.01, pch = 10))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  (G1 = ggcorrplot(Corr, hc.order = TRUE, type = "lower", lab = TRUE))

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  Fig_cor = ggplotly(G1)

## ----echo=FALSE, eval=FALSE----------------------------------------------
#  htmlwidgets::saveWidget(Fig_cor, "Fig_cor.html")

