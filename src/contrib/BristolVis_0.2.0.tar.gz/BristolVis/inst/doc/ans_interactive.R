## ---- include=FALSE------------------------------------------------------
data(bmov, package = "BristolVis")
head(bmov)

## ---- message=FALSE, warning=FALSE---------------------------------------
require(ggplot2)
require(plotly)
(G = ggplot(bmov, aes(Length, Rating)) + geom_point())

## ------------------------------------------------------------------------
summary(bmov$Year)
bmov$cat_timing = cut(bmov$Year, breaks = c(1930, 1990, 2000, 2005))

## ------------------------------------------------------------------------
(G = ggplot(bmov, aes(Length, Rating, color = cat_timing)) + geom_point())

## ------------------------------------------------------------------------
(G = G + scale_color_manual(values = c("blue", "yellow", "red")))

## ------------------------------------------------------------------------
Fig_scatter = ggplotly(G)

## ---- eval=FALSE---------------------------------------------------------
#  htmlwidgets::saveWidget(Fig_scatter, "Fig_scatter.html")

## ---- message=FALSE, warning=FALSE---------------------------------------
(G = ggplot(bmov[bmov$Year>=1980,], aes(Year)) + geom_histogram())

## ---- message=FALSE, warning=FALSE---------------------------------------
(G = G + geom_histogram(bins = 25))

## ---- message=FALSE, warning=FALSE---------------------------------------
Fig_hist = ggplotly(G)

## ---- eval=FALSE---------------------------------------------------------
#  htmlwidgets::saveWidget(Fig_hist, "Fig_hist.html")

## ------------------------------------------------------------------------
(G = ggplot(bmov, aes(x=cat_timing, y =Rating)) + geom_boxplot(aes(group = cat_timing)))

## ------------------------------------------------------------------------
Fig_box = ggplotly(G)

## ---- eval=FALSE---------------------------------------------------------
#  htmlwidgets::saveWidget(Fig_box, "Fig_box.html")

## ------------------------------------------------------------------------
data(iris)
head(iris)
require(ggcorrplot)
data_cont = iris[,1:4]
Corr = cor(data_cont)
corr.p = cor_pmat(data_cont)

## ------------------------------------------------------------------------
(G = ggcorrplot(Corr, method = "circle"))

## ------------------------------------------------------------------------
(G = ggcorrplot(Corr, hc.order = TRUE, type = "lower"))

## ------------------------------------------------------------------------
(G = ggcorrplot(Corr, hc.order = TRUE, type = "lower", p.mat = corr.p, sig.level = 0.01))

## ------------------------------------------------------------------------
(G = ggcorrplot(Corr, hc.order = TRUE, type = "lower", p.mat = corr.p, sig.level = 0.01, pch = 10))

## ------------------------------------------------------------------------
(G1 = ggcorrplot(Corr, hc.order = TRUE, type = "lower", lab = TRUE, lab_size = 3))

## ------------------------------------------------------------------------
Fig_cor = ggplotly(G1)

## ---- eval=FALSE---------------------------------------------------------
#  htmlwidgets::saveWidget(Fig_cor, "Fig_cor.html")

