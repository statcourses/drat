## ---- echo = TRUE, eval = FALSE------------------------------------------
#      library(BristolVis)
#      library(arsenal)
#      table_one <- tableby(diet ~ bmi + sex,
#                   data = bmi,
#                   test=TRUE, # include tests of associations between diet and exposures
#                   total=TRUE, # include a total column
#                   control=tableby.control(digits=1)) # to control how many decimal places are in the table
#      summary(table_one)

