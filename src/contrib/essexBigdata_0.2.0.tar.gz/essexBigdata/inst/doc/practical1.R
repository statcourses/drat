## ----echo=FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = NA)

## ----results='hide', message=FALSE---------------------------------------
require(essexBigdata)
data(measure, package = "essexBigdata")
# Details of the 'measure' dataset can be shown by:
?measure

## ----eval=FALSE----------------------------------------------------------
#  head(measure)
#  dim(measure)
#  colnames(measure)

## ------------------------------------------------------------------------
cov(measure[, c("chest", "waist", "hips")])

## ------------------------------------------------------------------------
cov(subset(measure, gender == "female")[, c("chest", "waist", "hips")])

## ----echo=FALSE----------------------------------------------------------
cov(subset(measure, gender == "male")[, c("chest", "waist", "hips")])

## ------------------------------------------------------------------------
cor(measure[, c("chest", "waist", "hips")])

## ------------------------------------------------------------------------
# variables are normailsed (centered at mean and scaled by the standard deviations)
x <- dist(scale(measure[, c("chest", "waist", "hips")]))
as.dist(round(as.matrix(x), 2)[1:12, 1:12])

