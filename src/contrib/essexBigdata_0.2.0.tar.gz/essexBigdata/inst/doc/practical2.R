## ------------------------------------------------------------------------
set.seed(02022015)    # to 
x <- matrix(rnorm(50*2), ncol=2)
x[1:25,1] <- x[1:25,1]+3
x[1:25,2] <- x[1:25,2]-4

## ------------------------------------------------------------------------
library("ggplot2")

## ------------------------------------------------------------------------
(G.data    <- ggplot(as.data.frame(x), aes(V1,V2)) + geom_point(size=4))

## ------------------------------------------------------------------------
my.km <- kmeans(x, centers=2, nstart=20)
my.km$cluster

## ---- results='hold'-----------------------------------------------------
G.clust   <- ggplot(as.data.frame(x), aes(V1,V2)) + geom_point(color=my.km$cluster, size=4)
G.data; G.clust

## ------------------------------------------------------------------------
my.km <- kmeans(x, centers=3, nstart=20)
my.km$cluster

## ---- results='hold'-----------------------------------------------------
G.clust   <- ggplot(as.data.frame(x), aes(V1,V2)) + geom_point(color=my.km$cluster, size=4)
G.data; G.clust

## ------------------------------------------------------------------------
my.km <- kmeans(x, centers=4, nstart=20)
my.km$cluster

## ---- results='hold'-----------------------------------------------------
G.clust   <- ggplot(as.data.frame(x), aes(V1,V2)) + geom_point(color=my.km$cluster, size=4)
G.data; G.clust

## ------------------------------------------------------------------------
my.km <- kmeans(x, centers=5, nstart=20)
my.km$cluster

## ---- results='hold'-----------------------------------------------------
G.clust   <- ggplot(as.data.frame(x), aes(V1,V2)) + geom_point(color=my.km$cluster, size=4)
G.data; G.clust

## ---- results='hide'-----------------------------------------------------
data("pottery", package = "HSAUR2")
head(pottery)
dim(pottery)

## ------------------------------------------------------------------------
s.pottery <- scale(pottery[,c(1:9)])    # normalise features
d.pottery <- dist(s.pottery)            # calculate distances between observations

## ---- fig.width=7, fig.height=4------------------------------------------
plot(hclust(d.pottery, method="complete"),labels=(as.character(pottery$kiln)),
     hang=-1,cex=.75, main="",xlab="complete-linkage",ylab="level",sub="")

## ---- fig.width=7, fig.height=4------------------------------------------
plot(hclust(d.pottery, method="complete"),labels=(as.character(pottery$kiln)),
     hang=-1,cex=.5, main="",xlab="complete-linkage",ylab="level",sub="")
plot(hclust(d.pottery, method="single"),labels=(as.character(pottery$kiln)),
     hang=-1,cex=.5, main="",xlab="single-linkage",ylab="level",sub="")
plot(hclust(d.pottery, method="average"),labels=(as.character(pottery$kiln)),
     hang=-1,cex=.5, main="",xlab="average-linkage",ylab="level",sub="")
plot(hclust(d.pottery, method="centroid"),labels=(as.character(pottery$kiln)),
     hang=-1,cex=.5, main="",xlab="centroid-linkage",ylab="level",sub="")

## ---- fig.width=7, fig.height=4------------------------------------------
d.pottery <- as.dist(1- cor(pottery[,c(1:9)])^2)
plot(hclust(d.pottery, method="average"),hang=-1,cex=.75,main="",xlab="average-linkage",ylab="level",sub="")

## ---- fig.width=7, fig.height=4------------------------------------------
library(clue)       # the package by which additive trees can be constructed
plot(ls_fit_addtree(d.pottery))

